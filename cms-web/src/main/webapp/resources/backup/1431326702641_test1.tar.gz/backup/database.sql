-- MySQL dump 10.13  Distrib 5.6.16, for Win64 (x86_64)
--
-- Host: localhost    Database: cms
-- ------------------------------------------------------
-- Server version	5.6.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isAttach` int(11) NOT NULL,
  `isImg` int(11) NOT NULL,
  `isIndexPic` tinyint(1) DEFAULT NULL,
  `newName` varchar(255) DEFAULT NULL,
  `oldName` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `suffix` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `topicId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_h3s12m669fw1c8y1qy3eccaq6` (`topicId`),
  CONSTRAINT `FK_h3s12m669fw1c8y1qy3eccaq6` FOREIGN KEY (`topicId`) REFERENCES `topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channels` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `custom_link` int(11) DEFAULT NULL,
  `custom_link_url` varchar(255) DEFAULT NULL,
  `is_index` int(11) DEFAULT NULL,
  `is_top_nav` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `orders` int(11) NOT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `pid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_6fwetswlauutd8cjw2iw3okpx` (`pid`),
  CONSTRAINT `FK_6fwetswlauutd8cjw2iw3okpx` FOREIGN KEY (`pid`) REFERENCES `channels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
INSERT INTO `channels` VALUES (1,0,'#',0,0,'用户管理模块',1,0,0,0,NULL),(2,0,'#',0,0,'用户管理1',3,0,0,0,1),(3,0,'#',0,0,'用户管理2',1,0,0,0,1),(4,0,'#',0,0,'用户管理3',2,0,0,0,1),(5,0,'#',0,0,'用户管理4',4,0,0,0,1),(6,0,'#',0,0,'文章管理模块',2,0,0,0,NULL),(7,0,'#',0,0,'文章管理1',1,0,0,0,6),(8,0,'#',0,0,'文章管理2',2,0,0,0,6),(9,0,'#',0,0,'文章管理3',3,0,0,0,6),(10,0,'#',0,0,'文章管理4',4,0,0,0,6),(11,0,'#',0,0,'系统管理模块',3,0,0,0,NULL),(12,0,'#',0,0,'系统管理1',1,0,0,0,11),(13,0,'#',0,0,'系统管理2',2,0,0,0,11),(14,0,'#',0,0,'系统管理3',3,0,0,0,11),(15,0,'#',0,0,'系统管理4',4,0,0,0,11),(16,0,'#',0,0,'招生管理模块',4,0,0,0,NULL),(17,0,'#',0,0,'招生管理1',1,0,0,0,16),(18,0,'#',0,0,'招生管理2',2,0,0,0,16),(19,0,'#',0,0,'招生管理3',3,0,0,0,16),(20,0,'#',0,0,'招生管理4',4,0,0,0,16);
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels_groups`
--

DROP TABLE IF EXISTS `channels_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channels_groups` (
  `groupId` bigint(20) NOT NULL,
  `channelId` bigint(20) NOT NULL,
  PRIMARY KEY (`groupId`,`channelId`),
  KEY `FK_4srdqe4m68chdy6p6798bm0q7` (`channelId`),
  KEY `FK_sg442hjwxkjgfi4hi9thd20y1` (`groupId`),
  CONSTRAINT `FK_4srdqe4m68chdy6p6798bm0q7` FOREIGN KEY (`channelId`) REFERENCES `channels` (`id`),
  CONSTRAINT `FK_sg442hjwxkjgfi4hi9thd20y1` FOREIGN KEY (`groupId`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels_groups`
--

LOCK TABLES `channels_groups` WRITE;
/*!40000 ALTER TABLE `channels_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `channels_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `descr` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups_users`
--

DROP TABLE IF EXISTS `groups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups_users` (
  `userId` bigint(20) NOT NULL,
  `groupId` bigint(20) NOT NULL,
  KEY `FK_n6m52pqlg5281qm2uaavhb4dn` (`groupId`),
  KEY `FK_2tfodhse2sbhj99l8dlds29h8` (`userId`),
  CONSTRAINT `FK_2tfodhse2sbhj99l8dlds29h8` FOREIGN KEY (`userId`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_n6m52pqlg5281qm2uaavhb4dn` FOREIGN KEY (`groupId`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups_users`
--

LOCK TABLES `groups_users` WRITE;
/*!40000 ALTER TABLE `groups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_pic`
--

DROP TABLE IF EXISTS `index_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `link_type` int(11) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `new_name` varchar(255) DEFAULT NULL,
  `old_name` varchar(255) DEFAULT NULL,
  `pos` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_pic`
--

LOCK TABLES `index_pic` WRITE;
/*!40000 ALTER TABLE `index_pic` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keyword`
--

DROP TABLE IF EXISTS `keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keyword` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `name_full_py` varchar(255) DEFAULT NULL,
  `name_short_py` varchar(255) DEFAULT NULL,
  `times` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keyword`
--

LOCK TABLES `keyword` WRITE;
/*!40000 ALTER TABLE `keyword` DISABLE KEYS */;
INSERT INTO `keyword` VALUES (15,'sdf','sdf','',1),(16,'gj','gj','',1),(17,'sdv','sdv','',1),(18,'d','d','',1),(19,'dc','dc','',0),(20,'你好','nihao','nh',1),(21,'呵呵','hehe','hh',1);
/*!40000 ALTER TABLE `keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `role_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'管理员','ROLE_ADMIN'),(2,'文章发布人员','ROLE_PUBLISH'),(3,'文章审核人员','ROLE_AUDIT');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `topic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) DEFAULT NULL,
  `channelPicId` int(11) NOT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  `createDate` datetime DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `publishDate` datetime DEFAULT NULL,
  `recommend` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `channelId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_i8gx08hh3nxbsftvib3spxhfr` (`channelId`),
  KEY `FK_jo3o1b7yswuopi26x1u58bhi4` (`userId`),
  CONSTRAINT `FK_i8gx08hh3nxbsftvib3spxhfr` FOREIGN KEY (`channelId`) REFERENCES `channels` (`id`),
  CONSTRAINT `FK_jo3o1b7yswuopi26x1u58bhi4` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic`
--

LOCK TABLES `topic` WRITE;
/*!40000 ALTER TABLE `topic` DISABLE KEYS */;
/*!40000 ALTER TABLE `topic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_date` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_sb8bbouer5wak8vyiiy4pf2bx` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (3,'2015-03-30 20:39:51','1255239473@qq.com','黎红','670b14728ad9902aecba32e22fa4f6bd','18270837982',1,'admin'),(4,'2015-03-30 20:40:09','1255239473@qq.com','黎红','670b14728ad9902aecba32e22fa4f6bd','18270837982',1,'lihong');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_roles` (
  `userId` bigint(20) NOT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`roleId`,`userId`),
  KEY `FK_onke18cwkc3wbu3kglh0kb175` (`roleId`),
  KEY `FK_6o9f17e2ht6y5sxv04ii3bh6u` (`userId`),
  CONSTRAINT `FK_6o9f17e2ht6y5sxv04ii3bh6u` FOREIGN KEY (`userId`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_onke18cwkc3wbu3kglh0kb175` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_roles`
--

LOCK TABLES `users_roles` WRITE;
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` VALUES (3,1),(4,2),(4,3);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-11 14:45:01
